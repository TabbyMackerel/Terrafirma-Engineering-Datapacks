// priority: 0

onEvent('item.tags', event => {

	// beewax
	event.add('forge:wax', 'firmalife:beeswax')
	// IP Molotov Creosote Recipes

	event.add('tfe:creosote_molotov_cloth', 'tfc:burlap_cloth')
	event.add('tfe:creosote_molotov_cloth', 'tfc:silk_cloth')
	event.add('tfe:creosote_molotov_cloth', 'tfc:wool_cloth')	

})

onEvent('fluid.tags', event => {

	// create big cannon addon
	event.add('tfc:metal/cast_iron', 'createbigcannons:molten_cast_iron')
	event.add('tfc:metal/bronze', 'createbigcannons:molten_bronze')

	event.add('tfe:bronze_cannon_material', 'tfc:metal/bronze')
	event.add('tfe:bronze_cannon_material', 'createbigcannons:molten_cast_iron')
	event.add('tfe:cast_iron_cannon_material', 'tfc:metal/cast_iron')
	event.add('tfe:cast_iron_cannon_material', 'createbigcannons:molten_cast_iron')
	
	// petroleum jelly materials
	
	event.add('tfe:petroleum_jelly_ointment_oils', 'tfc:olive_oil')
	event.add('tfe:petroleum_jelly_ointment_oils', 'tfc:tallow')
	event.add('tfe:petroleum_jelly_ointment_oils', 'createaddition:seed_oil')
	event.add('tfe:petroleum_jelly_ointment_oils', 'immersiveengineering:plantoil')

	event.add('tfe:petroleum_jelly_ointment_oil' ,'kubejs:petroleum_jelly_ointment_oil')

	// IP Ethylene tag add
	event.add('forge:ethene', 'immersivepetroleum:ethylene')

})