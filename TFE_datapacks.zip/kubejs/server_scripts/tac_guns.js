// priority: 0

onEvent('recipes', event => {
	// Change recipes here

	// gun parts
	//event.custom({"type":"immersiveengineering:blueprint",
	//	"category":"gunparts_basic",
	//	"inputs":[
	//	{"base_ingredient":{"item":"tfc:brass_mechanisms"}},
	//	{"item":"immersiveengineering:component_steel","count":2},
	//	{"tag":"forge:wires/steel", "count":5},
	//	{"item":"immersiveengineering:component_iron","count":4},
	//	{"item":"firmalife:metal/sheet/stainless_steel","count":2},
	//	{"tag":"forge:rods/steel","count":2}],
	//	"result":{"item":"kubejs:basic_gun_parts"}})

})

onEvent('item.tags', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// ~ WW2 guns
	event.add('tfe:tac_gun_interwar_and_ww2', ['tac:m1911', 'tac:m1a1_smg', 'tac:db_short', 'tac:dp28'])
	
	// Cold War guns (western)
	event.add('tfe:tac_gun_coldwar_western', ['tac:colt_python', 'tac:glock_17', 'tac:m92fs', 'tac:deagle_357', 'tac:tec_9', 'tac:glock_18', 'tac:micro_uzi', 'tac:hk_mp5a5', 'tac:uzi', 'tac:fn_fal', 'tac:hk_g3', 'tac:m24', 'tac:m82a2', 'tac:m870_classic', 'tac:m60', 'tac:m249'])

	// Cold War guns (eastern)
	event.add('tfe:tac_gun_coldwar_eastern', ['tac:cz75', 'tac:ak47', 'tac:type81_x','tac:rpk'])

	// Modern guns
	event.add('tfe:tac_gun_modernwar', ['tac:sti2011', 'tac:cz75_auto', 'tac:mk23', 'tac:tti_g34', 'tac:timeless_50', 'tac:vector45', 'tac:mp7', 'tac:mp9', 'tac:udp_9', 'tac:p90', 'tac:qbz_95', 'tac:mk14', 'tac:m4', 'tac:hk416_a5', 'tac:sig_mcx_spear', 'tac:sks_tactical', 'tac:qbz_191', 'tac:m16a4', 'tac:scar_h', 'tac:scar_l', 'tac:mk47', 'tac:spr15', 'tac:mk18_mod1', 'tac:ai_awp', 'tac:scar_mk20', 'tac:mrad', 'tac:aa_12', 'tac:m1014'])

	// Rocket Launcher
	event.add('tfe:rocket_launcher', 'tac:rpg7')

	// Grenades
	event.add('tfe:grenade', ['tac:light_grenade', 'tac:baseball_grenade'], )
	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})