// priority: 0

onEvent('recipes', event => {
	// Change recipes here
	// IE disable recipes (+ post addon)
	event.remove({id: 'immersiveengineering:crafting/stick_iron'})
	event.remove({id: 'immersiveengineering:crafting/stick_steel'})
	event.remove({id: 'immersiveengineering:crafting/stick_aluminum'})
	// post addon
	event.remove({id: 'immersiveposts:crafting/has_gold_rod'})
	event.remove({id: 'immersiveposts:crafting/has_copper_rod'})
	event.remove({id: 'immersiveposts:crafting/has_lead_rod'})
	event.remove({id: 'immersiveposts:crafting/has_silver_rod'})
	event.remove({id: 'immersiveposts:crafting/has_nickel_rod'})
	event.remove({id: 'immersiveposts:crafting/has_constantan_rod'})
	event.remove({id: 'immersiveposts:crafting/has_electrum_rod'})
	event.remove({id: 'immersiveposts:crafting/has_uranium_rod'})

	// Beyond Earth disable
	event.remove({id: 'beyond_earth:iron_stick'})
	event.remove({id: 'beyond_earth:hammer'})

	// TAC old scope disable
	event.remove({output:'tac:old_8x_scope'})
	event.remove({output:'tac:old_4x_scope'})
	event.remove({output:'tac:762x25'})
})

onEvent('item.tags', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})