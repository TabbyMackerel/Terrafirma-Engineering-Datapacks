onEvent('item.registry', event => {
  // chrome dust
	event.create('chrom_dust').displayName('Chrom Grit')
    
  // foods
	event.create('hardtack').displayName('hardtack').maxStackSize(16).food(food => {food.hunger(2).saturation(0.5)})

  // modpack added custom canned foods
  event.create('canned_cornbeef').displayName('Canned Cornbeef').texture("rosia:item/cans/grain_can").maxStackSize(8).food(food => {food.hunger(8).saturation(0.7)})
  event.create('canned_bakedbeans').displayName('Canned Baked Beans').texture("rosia:item/cans/soup_can").maxStackSize(8).food(food => {food.hunger(5).saturation(0.5)})
  event.create('canned_sauerkraut').displayName('Canned Sauerkraut').texture("rosia:item/cans/vegetables_can").maxStackSize(8).food(food => {food.hunger(3).saturation(0.3)})
  event.create('canned_processed_meat').displayName('Canned Processd Meat').texture("rosia:item/cans/protein_can").maxStackSize(8).food(food => {food.hunger(6).saturation(0.6)})

  // foods (farmer's delights and addon canned foods)
  event.create('canned_bone_broth').displayName('Canned Bone Broth').maxStackSize(8).food(food => {food.hunger(8).saturation(0.7)})
  event.create('canned_beef_stew').displayName('Canned Beef Stew').maxStackSize(8).food(food => {food.hunger(12).saturation(0.8)})
  event.create('canned_chicken_soup').displayName('Canned Chicken Soup').maxStackSize(8).food(food => {food.hunger(14).saturation(0.75)})
  event.create('canned_vegetable_soup').displayName('Canned Vegetable Soup').maxStackSize(8).food(food => {food.hunger(12).saturation(0.8)})
  event.create('canned_fish_stew').displayName('Canned Fish Stew').maxStackSize(8).food(food => {food.hunger(12).saturation(0.8)})
  event.create('canned_pumpkin_soup').displayName('Canned Pumpkin Soup').maxStackSize(8).food(food => {food.hunger(14).saturation(0.75)})
  event.create('canned_baked_cod_stew').displayName('Canned Baked Cod Stew').maxStackSize(8).food(food => {food.hunger(14).saturation(0.75)})
  event.create('canned_noodle_soup').displayName('Canned Noodle Soup').maxStackSize(8).food(food => {food.hunger(14).saturation(0.75)})
  event.create('canned_pasta_with_meatballs').displayName('Canned Pasta With Meatballs').maxStackSize(8).food(food => {food.hunger(12).saturation(0.8)})
  event.create('canned_pasta_with_mutton_chop').displayName('Canned Pasta With Mutton Chop').maxStackSize(8).food(food => {food.hunger(12).saturation(0.8)})
  event.create('canned_vegetable_noodles').displayName('Canned Vegetable Noodles').maxStackSize(8).food(food => {food.hunger(14).saturation(0.75)})
  event.create('canned_ratatouille').displayName('Canned Ratatouille').maxStackSize(8).food(food => {food.hunger(10).saturation(0.6)})
  event.create('canned_squid_ink_pasta').displayName('Canned Squid Ink Pasta').maxStackSize(8).food(food => {food.hunger(14).saturation(0.75)})
  event.create('canned_apple_pie').displayName('Canned Apple Pie').maxStackSize(8).food(food => {food.hunger(12).saturation(1.2)})
  event.create('canned_sweet_berry_cheesecake').displayName('Canned Sweet Berry Cheesecake').maxStackSize(8).food(food => {food.hunger(12).saturation(1.2)})
  event.create('canned_chocolate_pie').displayName('Canned Chocolate Pie').maxStackSize(8).food(food => {food.hunger(12).saturation(1.2)})
  event.create('canned_kelp_roll').displayName('Canned Kelp Roll').maxStackSize(8).food(food => {food.hunger(12).saturation(0.6)})
  // (added from mod crops and meat canned foods)
  
  // gun parts
  event.create('basic_gun_parts').displayName('Basic Gun Parts')
  event.create('enhanced_gun_parts').displayName('Enhanced Gun Parts')
  event.create('advanced_gun_parts').displayName('Advanced Gun Parts')    

	// medical items and drugs
	event.create("petroleum_jelly_ointment", "basic")
        .displayName('Petroleum Jelly Ointment')
        .useAnimation("bow")
        .useDuration((itemstack) => 10)
        .use((level, player, hand) => true)
        .finishUsing((itemstack, level, entity) => {
            let effects = entity.potionEffects;
            effects.add("resistance", 20 * 120, 1)
            itemstack.itemStack.shrink(1)
            return itemstack;
	})

	event.create('speed_maniac', 'basic')
    .displayName('Maniac Speedrun')
    .useAnimation('bow')
    .food(food => {
      food.hunger(0) // 허기 수준
        .saturation(0) // 포화도
        .alwaysEdible() // 언제나 먹을 수 있는지 여부
        .effect('minecraft:speed', 20 * 180, 1, 1.0) // 지속 시간: 3분 (180초), 강도: 1, 확률: 100%
        .effect('minecraft:haste', 20 * 180, 1, 1.0) // 지속 시간: 3분 (180초), 강도: 1, 확률: 100%
    });
});

onEvent('player.tick', event => {
  const entities = event.server.getEntities();
  entities.forEach(entity => {
    if (entity.type === 'player') {
      const isPositiveEffectActive = entity.hasEffect('minecraft:speed') && entity.hasEffect('minecraft:haste');
      const isNegativeEffectActive = entity.hasEffect('minecraft:mining_fatigue') && entity.hasEffect('minecraft:slowness');

      if (isPositiveEffectActive && !isNegativeEffectActive && !entity.knownManiacSpeedrun) {
        // 긍정적 효과가 처음 발동한 경우
        entity.knownManiacSpeedrun = true;
        // 부정적 효과를 추가하기 위해 3분 후에 playerManiacSpeedrun 함수 실행
        event.server.schedule(20 * 360, () => {
          playerManiacSpeedrun(entity);
          entity.knownManiacSpeedrun = false; // 부정적 효과가 추가될 때 긍정적 효과 상태를 초기화합니다.
        });
      }
    }
  });
});

function playerManiacSpeedrun(player) {
  // 부정적 효과를 추가
  player.addEffect('minecraft:mining_fatigue', 20 * 720, 3, 1.0); // 6분 동안 채굴 피로 4단계
  player.addEffect('minecraft:slowness', 20 * 720, 3, 1.0); // 6분 동안 감속 4단계
}

onEvent('block.registry', event => {
	// Register new blocks here
	// event.create('example_block').material('wood').hardness(1.0).displayName('Example Block')
})

onEvent('fluid.registry', event => {
  event.create('petroleum_jelly_ointment_oil')
    .thickTexture(0xFFFACD)
    .bucketColor(0xFFFACD)
    .displayName('Petroleum Jelly Oil')
    .noBlock()
})